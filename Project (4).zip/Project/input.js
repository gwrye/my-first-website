document.getElementById('prForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way

    const eventInput = document.getElementById('event').value;
    const timeInput = document.getElementById('time').value;

    // Get existing records from local storage
    let records = JSON.parse(localStorage.getItem('prRecords')) || [];

    // Add new record
    records.push({ event: eventInput, time: timeInput });

    // Save updated records back to local storage
    localStorage.setItem('prRecords', JSON.stringify(records));

    // Clear the input fields
    document.getElementById('event').value = '';
    document.getElementById('time').value = '';
});

// Function to navigate to the table page
function viewTable() {
    window.location.href = 'table.html';
}
